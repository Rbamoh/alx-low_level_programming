#include "lists.h"
/**
 * print_listint_safe - Entry Point
 * @head: head
 * Return: 0
 */
size_t print_listint_safe(const listint_t *head)
{
	if (head == NULL)
		exit(98);

	return (0);
}
