#include "holberton.h"
/**
 * print_number - a function that prints an integer
 * @n: input
 * Return: inputted integer
 */
void print_number(int n)
{

	return (0);
}
