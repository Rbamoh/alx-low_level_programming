#ifndef HOLBERTON_H
#define HOLBERTON_H

char _putchar(char c);
void print_alphabet(void);
void print_alphabet_x10(void);
int _islower(int c);
int _isalpha(int c);
int print_sign(int n);
int _abs(int);
int print_last_digit(int nld);
void jack_bauer(void);
void times_table(void);
int add(int one, int two);
void print_to_98(int n);
void print_times_table(int n);

#endif /* HOLBERTON_H */
