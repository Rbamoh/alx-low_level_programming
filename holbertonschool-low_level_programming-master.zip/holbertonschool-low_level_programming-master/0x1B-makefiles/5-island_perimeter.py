#!/usr/bin/python3
"""island_perimeter module
"""


def island_perimeter(grid):
    """Returns perimeter of the grid
    """
