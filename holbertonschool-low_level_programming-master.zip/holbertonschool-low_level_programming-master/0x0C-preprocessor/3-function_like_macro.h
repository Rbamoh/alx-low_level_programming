#ifndef FUNCTION_LIKE_MACRO
#define FUNCTION_LIKE_MACRO

#define ABS(x) (x * ((x < 0) * (-1) + (x > 0)))

#endif /* FUNCTION_LIKE_MACRO */
