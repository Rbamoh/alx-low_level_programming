#include <stdio.h>
#include "holberton.h"
/**
 * main - prints its name + \n
 * @argc: number of arguments typed
 * @argv: array pointing to arguements
 * Return: 0
 */
int main(int argc, char *argv[])
{
	argc = 0;

	printf("%s\n", argv[argc]);
	return (0);
}
